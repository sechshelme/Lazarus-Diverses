This demo demonstrates how to use fpspreadsheet to read and write Excel 5.x/Excel 95
xls files.

Please run the write demo before the read demo so the required spreadsheet file
is generated.