This sample project demonstrates how fpspreadsheet can follow the hyperlinks 
to other spreadsheet files and copy the linked sheets to a new document.

Please run the write demos ../ooxmldemo/ooxmlwrite and ../excel8demo/excel8write 
before running this project in order to generate required spreadsheet files.
